package com.example.teamnova_android;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class Memo_Adapter extends RecyclerView.Adapter<Memo_Adapter.Memo_ViewHolder> {

    //생성자에 들어갈 변수 미리 선언.
    Context context;
    LayoutInflater inflater;
    int layout;

    //로컬 데이터 객체 선언
    public static ArrayList<Memo_Data> memo_data = new ArrayList<>();

    // 어뎁터 생성자. - context, layout 선언
    public Memo_Adapter(Context context, int layout) {
        this.context = context;
        this.layout = layout;
        inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    // 내부클래스 ,뷰홀더 선언
    public class Memo_ViewHolder extends RecyclerView.ViewHolder {
        TextView memo_content;
        TextView memo_delete;
        TextView memo_modify;

        public Memo_ViewHolder(@NonNull View itemView) {
            super(itemView);
            memo_content = itemView.findViewById(R.id.note_text);
            memo_delete = itemView.findViewById(R.id.note_delete);
            memo_modify = itemView.findViewById(R.id.note_modify);
        }
    }

    // 뷰홀더 생성 (xml을 컨텍스트가 메모리에 올려줌)
    @NonNull
    @Override
    public Memo_ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.memo_layout,parent,false);
        return new Memo_ViewHolder(view);
    }

    // 데이터 셋에서 뷰에게 위치에 맞는 데이터를 뿌려줌.
    @Override
    public void onBindViewHolder(@NonNull Memo_ViewHolder holder, int position) {
        int pos = position;
        Memo_Data data = memo_data.get(position);
        holder.memo_content.setText(data.getMemo_content());
        holder.memo_delete.setTag(position);
        holder.memo_modify.setTag(position);

        holder.memo_modify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 수정 dialog 로 이동하기!
                int position = (int) v.getTag();

                Memo_Data data;
                data = memo_data.get(position);
                String memo_content = data.getMemo_content();

                memo_modify_dialog dialog = new memo_modify_dialog();
                Bundle bundle = new Bundle();
                bundle.putInt("position", pos);
                bundle.putString("memo_content",memo_content);
                dialog.setArguments(bundle);
                dialog.show(((FragmentActivity)context).getSupportFragmentManager(), "memo_modify_dialog");
            }
        });

        holder.memo_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog.Builder builder = new AlertDialog.Builder(holder.itemView.getContext());

                builder.setTitle("삭제하시겠어요?");
                builder.setPositiveButton("삭제", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int item) {
                        int itemPosition = (int) v.getTag();
                        memo_data.remove(itemPosition);
                        notifyDataSetChanged();
                        dialog.dismiss();
                    }
                });
                builder.setNegativeButton("취소", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        notifyDataSetChanged();
                        dialog.dismiss();
                    }
                });
                builder.show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return memo_data.size();
    }

    // activity에서 호출되는 애
    public void addItem(Memo_Data item) {
        memo_data.add(item);
        notifyDataSetChanged();
    }

    public void modifyItem(int position, Memo_Data item) {
        memo_data.set(position, item);
        notifyDataSetChanged();
    }





}

//package com.example.teamnova_android;
//
//import android.os.Bundle;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//
//import androidx.annotation.NonNull;
//import androidx.annotation.Nullable;
//import androidx.fragment.app.Fragment;
//
//import com.google.android.material.floatingactionbutton.FloatingActionButton;
//
//public class timer extends Fragment {
//    private View view;
//    private FloatingActionButton add_timer;
//
//    public static final String TAG = "timerFragment";
//
//
//    @Nullable
//    @Override
//    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
//       view = inflater.inflate(R.layout.timer, container, false);
//
//        add_timer = view.findViewById(R.id.floating_action_button_timer);
//        add_timer.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                timer_select_dialog dialog = new timer_select_dialog();
//                dialog.show(getFragmentManager(), "timer_dialog" );
//
//            }
//        });
//       return view;
//    }
//}

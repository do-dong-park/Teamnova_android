package com.example.teamnova_android;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class login_signUp extends AppCompatActivity  {

    private EditText signUpEmail, signUpPassword, signUpConfirm;
    private Button signUp;
    private Toast toast;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_sign_up);

        signUpEmail = (EditText)findViewById(R.id.sign_up_email);
        signUpPassword = (EditText)findViewById(R.id.sign_up_password);
        signUpConfirm = (EditText)findViewById(R.id.sign_up_confirm_password);
        signUp = (Button)findViewById(R.id.sign_up);

        signUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 회원가입 조건 파악이 필요해요!

                String correctEmail = signUpEmail.getText().toString();
                String correctPassword = signUpPassword.getText().toString();
                String correctConfirm = signUpConfirm.getText().toString();

                if(correctEmail.isEmpty() == false && correctPassword.isEmpty() == false && correctPassword.equals(correctConfirm) == true ) {

                    Intent intent = new Intent(getApplicationContext(), login.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP); // 회원가입창 닫기, 로그인 창으로

                    intent.putExtra("email", correctEmail);
                    intent.putExtra("password", correctPassword);
                    intent.putExtra("confirm", correctConfirm);

                    startActivity(intent);
                } else if (correctEmail.isEmpty() == true || !correctEmail.contains("@")) {
                    //이메일을 입력해주세요.
                    signUpEmail.setText("");
                    toast = Toast.makeText(getApplicationContext(), "이메일을 입력해주세요.", Toast.LENGTH_SHORT);
                    toast.show();

                } else if (correctPassword.isEmpty() == true) {
                    signUpPassword.setText("");
                    signUpConfirm.setText("");
                    toast = Toast.makeText(getApplicationContext(), "비밀번호를 입력해주세요.", Toast.LENGTH_SHORT);
                    toast.show();

                } else if (correctPassword.equals(correctConfirm) == false) {
                    signUpPassword.setText("");
                    signUpConfirm.setText("");
                    // 비밀번호와 비밀번호 확인이 일치하지 않습니다.
                    toast = Toast.makeText(getApplicationContext(), "비밀번호가 일치하지 않습니다.", Toast.LENGTH_SHORT);
                    toast.show();

                } else {
                    signUpEmail.setText("");
                    signUpPassword.setText("");
                    signUpConfirm.setText("");
                    toast = Toast.makeText(getApplicationContext(), "회원가입 실패, 다시 시도해주세요.", Toast.LENGTH_SHORT);
                    toast.show();
                }
            }
       });




    }
}

package com.example.teamnova_android;

public class timer_preset_data {
    private String title;
    private String timeSet;

    public timer_preset_data(String title, String timeSet) {
        this.title = title;
        this.timeSet = timeSet;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getTimeSet() {
        return timeSet;
    }

    public void setTimeSet(String timeSet) {
        this.timeSet = timeSet;
    }
}

package com.example.teamnova_android;

import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class timer_stopwatch extends AppCompatActivity {
    long start_time;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.timer_stopwatch_layout);

        start_time = System.currentTimeMillis();
    }

    @Override
    public void onBackPressed() {
        timer_exit_dialog dialog = new timer_exit_dialog();

        Bundle bundle = new Bundle();
        bundle.putLong("Start_time", start_time);
        dialog.setArguments(bundle);

        dialog.show(getSupportFragmentManager(), "timer_exit_dialog");
    }
}

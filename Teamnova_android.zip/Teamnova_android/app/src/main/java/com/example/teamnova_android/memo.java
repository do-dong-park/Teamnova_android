package com.example.teamnova_android;

import android.content.Intent;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import static com.example.teamnova_android.memo_modify_dialog.is_modify_memo;
import static com.example.teamnova_android.memo_write.is_add_memo;

public class memo extends AppCompatActivity {
    private FloatingActionButton add_memo;
    private BottomNavigationView bottomNavigationView;
    private RecyclerViewEmptySupport recyclerView;
    private Memo_Adapter memo_adapter;
    private long backKeyPressedTime = 0; // 마지막으로 뒤로가기 버튼 눌렀던 시간 저장
    private Toast toast;
    private Intent intent;
    private String memo_content;
    private int position;
    private androidx.appcompat.widget.Toolbar Toolbar;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.memo);

        Toolbar = (androidx.appcompat.widget.Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(Toolbar);
        getSupportActionBar().setTitle("메모장");

        recyclerView = (RecyclerViewEmptySupport) findViewById(R.id.memo_recyclerview);
        recyclerView.setEmptyView(findViewById(R.id.list_empty));
        setRecyclerView();



        bottomNavigationView = findViewById(R.id.bottomNavigationView);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.action_todo:
                        intent = new Intent(getApplicationContext(), todo.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                        intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                        startActivity(intent);
                        break;
                    case R.id.action_memo:
                        break;
                    case R.id.action_timer:
                        intent = new Intent(getApplicationContext(), MainActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                        intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                        startActivity(intent);
                        break;
                }
                return true;
            }
        });

        add_memo = findViewById(R.id.floating_action_button_memo);
        add_memo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                memo_write dialog = new memo_write();
                dialog.show(getSupportFragmentManager(), "memo_dialog");
            }
        });

    }

    //레이아웃 및 어뎁터 결정.
    public void setRecyclerView() {
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getApplicationContext());
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(linearLayoutManager);

        memo_adapter = new Memo_Adapter(this, R.layout.memo_layout);
        recyclerView.setAdapter(memo_adapter);
        recyclerView.setHasFixedSize(true);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if(null != intent && is_add_memo == true) {
            memo_content = intent.getStringExtra("memo_content");
            setIntent(intent);
        } else if (null != intent && is_modify_memo == true) {
            memo_content = intent.getStringExtra("memo_content");
            position = intent.getIntExtra("position",0);

            setIntent(intent);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        overridePendingTransition(0,0);
        if(is_add_memo == true) {
            is_add_memo = false;
            memo_adapter.addItem(new Memo_Data(memo_content));
            memo_adapter.notifyDataSetChanged();
        } else if(is_modify_memo == true) {
            is_modify_memo = false;
            memo_adapter.modifyItem(position,new Memo_Data(memo_content));
            memo_adapter.notifyDataSetChanged();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        overridePendingTransition(0,0);
    }

    @Override
    public void onBackPressed() {
        if (System.currentTimeMillis() > backKeyPressedTime + 2000 ) { // 2초 내로 한 번 더 뒤로가기 입력 없으면 문구 출력
            backKeyPressedTime = System.currentTimeMillis();
            toast = Toast.makeText(this, "\'뒤로\' 버튼을 한번 더 누르시면 종료됩니다.", Toast.LENGTH_SHORT);
            ViewGroup group = (ViewGroup)toast.getView();
            TextView msgTextView = (TextView)group.getChildAt(0);
            msgTextView.setTextSize(TypedValue.COMPLEX_UNIT_DIP,14);
            toast.show();
            return;

        }

        if(System.currentTimeMillis() <= backKeyPressedTime +2000) { // 2초 내로 한 번 더 뒤로가기 입력 있으면 종료
            finishAffinity();
            toast.cancel();
        }
    }


}

//    public static final String TAG = "memoFragment";
//    @Nullable
//    @Override
//    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
//       view = inflater.inflate(R.layout.memo, container, false);
//
//       add_memo = view.findViewById(R.id.floating_action_button_memo);
//       add_memo.setOnClickListener(new View.OnClickListener() {
//           @Override
//           public void onClick(View v) {
//               Log.d(TAG, "onclick : opening memo write dialog");
//               memo_write dialog = new memo_write();
//               dialog.show(getFragmentManager(), "memo_dialog");
//           }
//       });
//       return view;
//    }







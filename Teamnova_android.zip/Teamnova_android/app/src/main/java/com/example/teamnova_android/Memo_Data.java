package com.example.teamnova_android;

public class Memo_Data {
    private String memo_content;

    public Memo_Data(String memo_content) {
        this.memo_content = memo_content;
    }

    public String getMemo_content() {
        return memo_content;
    }

    public void setMemo_content(String memo_content) {
        this.memo_content = memo_content;
    }
}

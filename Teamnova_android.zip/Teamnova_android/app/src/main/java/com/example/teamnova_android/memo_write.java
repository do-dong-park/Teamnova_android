package com.example.teamnova_android;
import android.content.Intent;


import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.DialogFragment;

public class memo_write extends DialogFragment {
    private static final String TAG = "memo_dialog";

    //widget
    private EditText mInput;
    public TextView mActionOk, mActionCancel;
    public static boolean is_add_memo = false;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.memo_write_layout,container, false);
        mActionOk = view.findViewById(R.id.memo_save);
        mActionCancel = view.findViewById(R.id.memo_cancel);
        mInput = view.findViewById(R.id.memo_editText);

        mActionOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "onClick : memo save");
                String memo_content = mInput.getText().toString();
                is_add_memo = true;

                // 값입력_액티비티에서 사용
                Intent intent = new Intent(getContext(), memo.class); //액티비티 전환
                // 전달할 값 ( 첫번째 인자 : key, 두번째 인자 : 실제 전달할 값 )
                intent.putExtra("memo_content", memo_content);
                intent.addFlags (Intent.FLAG_ACTIVITY_NO_ANIMATION);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(intent);
                getDialog().dismiss();
            }
        });

        mActionCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "onClick : memo cancel");
                getDialog().dismiss();
            }
        });
        return view;
    }



    @Override
    public void onResume() {
        // Sets the height and the width of the DialogFragment
        int width = ConstraintLayout.LayoutParams.MATCH_PARENT;
        int height = ConstraintLayout.LayoutParams.WRAP_CONTENT;
        getDialog().getWindow().setLayout(width, height);

        super.onResume();
    }


}

package com.example.teamnova_android;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Locale;

public class timer_layout extends AppCompatActivity {
    long start_time;

    private TextView timeText;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.timer_layout);

        // 타이머 실행 시간 구하기.
        start_time = System.currentTimeMillis();


        timeText = (TextView) findViewById(R.id.text_view_countdown);

        Intent intent = new Intent(this.getIntent());

        String timeSet = intent.getStringExtra("timeSet");

        String[] array = timeSet.split(":");

        int hour = Integer.parseInt(array[0]);
        int minute = Integer.parseInt(array[1]);
        int second = Integer.parseInt(array[2]);

        String timerSet = String.format(Locale.getDefault(), "%02d:%02d:%02d",hour,minute,second);

        timeText.setText(timerSet);


    }

    @Override
    public void onBackPressed() {
        timer_exit_dialog dialog = new timer_exit_dialog();

        Bundle bundle = new Bundle();
        bundle.putLong("Start_time", start_time);
        dialog.setArguments(bundle);

        dialog.show(getSupportFragmentManager(), "timer_exit_dialog");
    }
}

package com.example.teamnova_android;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class Todo_Adapter extends RecyclerView.Adapter<Todo_Adapter.Todo_ViewHolder> {
    Context context;
    LayoutInflater layoutInflater;
    int layout;

    public static ArrayList<Todo_Data> todo_data = new ArrayList<>();

    public Todo_Adapter(Context context, int layout) {
        this.context = context;
        this.layout = layout;
        layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    public class Todo_ViewHolder extends RecyclerView.ViewHolder {
        CheckBox todoBox;
        TextView DeleteTodo;
        TextView ModifyTodo;

        public Todo_ViewHolder(@NonNull View itemView) {
            super(itemView);
            todoBox = itemView.findViewById(R.id.Todo_checkBox);
            DeleteTodo = itemView.findViewById(R.id.todo_delete);
            ModifyTodo= itemView.findViewById(R.id.todo_modify);
        }
    }

    @NonNull
    @Override
    public Todo_ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = layoutInflater.inflate(R.layout.todo_task_layout,parent,false);
        return new Todo_ViewHolder(view);
    }


    @Override
    public void onBindViewHolder(@NonNull Todo_ViewHolder holder, int position) {

        // 데이터의 리스트에서 아이템을 뽑아 냄.
        Todo_Data item = todo_data.get(position);
        holder.todoBox.setText(item.getTodo_content());

        holder.DeleteTodo.setTag(position);
        holder.ModifyTodo.setTag(position);

        holder.ModifyTodo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int position = (int) v.getTag();

                Todo_Data data;
                data = todo_data.get(position);
                String todo_content = data.getTodo_content();

                todo_modify_dialog dialog = new todo_modify_dialog();
                Bundle bundle = new Bundle();
                bundle.putInt("position", position);
                bundle.putString("todo_content",todo_content);
                dialog.setArguments(bundle);
                dialog.show(((FragmentActivity)context).getSupportFragmentManager(), "todo_modify_dialog");
            }
        });


        holder.DeleteTodo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(holder.itemView.getContext());

                builder.setTitle("삭제하시겠어요?");
                builder.setPositiveButton("삭제", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int item) {
                        int itemPosition = (int) v.getTag();
                        todo_data.remove(itemPosition);
                        notifyDataSetChanged();
                        dialog.dismiss();
                    }
                });
                builder.setNegativeButton("취소", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        notifyDataSetChanged();
                        dialog.dismiss();
                    }
                });
                builder.show();
            }
        });


    }

    @Override
    public int getItemCount() {
        return todo_data.size();
    }

    public void addItem(Todo_Data item){
        todo_data.add(item);
        notifyDataSetChanged();
    }

    public void modifyItem(int position, Todo_Data item) {

        todo_data.set(position, item);
        notifyDataSetChanged();

    }





}

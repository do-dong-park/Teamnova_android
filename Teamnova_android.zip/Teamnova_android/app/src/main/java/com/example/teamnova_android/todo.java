package com.example.teamnova_android;

import android.content.Intent;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import static com.example.teamnova_android.todo_modify_dialog.is_modify_todo;
import static com.example.teamnova_android.todo_new_task.is_add_todo;

public class todo extends AppCompatActivity {
    private BottomNavigationView bottomNavigationView;
    private FloatingActionButton add_todo;
    private long backKeyPressedTime = 0; // 마지막으로 뒤로가기 버튼 눌렀던 시간 저장
    private Toast toast;
    private Intent intent;
    private String todo_content;
    private int  pos;
    private Toolbar Toolbar;
    RecyclerViewEmptySupport recyclerView;
    Todo_Adapter todo_adapter;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.todo);

        Toolbar = (androidx.appcompat.widget.Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(Toolbar);
        getSupportActionBar().setTitle("To Do List");

        recyclerView = findViewById(R.id.todo_recyclerview);
        recyclerView.setEmptyView(findViewById(R.id.list_empty));
        setRecyclerView();

        bottomNavigationView = findViewById(R.id.bottomNavigationView);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.action_todo:
                        break;
                    case R.id.action_memo:
                        intent = new Intent(getApplicationContext(), memo.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                        intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                        startActivity(intent);
                        break;
                    case R.id.action_timer:
                        intent = new Intent(getApplicationContext(), MainActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                        intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                        startActivity(intent);
                        break;
                }
                return true;
            }
        });

        add_todo = findViewById(R.id.floating_action_button_todo);
        add_todo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                todo_new_task dialog = new todo_new_task();
                dialog.show(getSupportFragmentManager(), "todo_dialog");
            }
        });

    }

    //레이아웃 및 어뎁터 결정.
    public void setRecyclerView() {
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getApplicationContext());
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(linearLayoutManager);

        todo_adapter = new Todo_Adapter(this, R.layout.todo_task_layout);
        recyclerView.setAdapter(todo_adapter);
        recyclerView.setHasFixedSize(true);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if(null != intent && is_add_todo == true) {
            todo_content = intent.getStringExtra("todo_content");
            setIntent(intent);
        } else if(null != intent && is_modify_todo == true) {
            todo_content = intent.getStringExtra("todo_content");
            pos = intent.getIntExtra("position",0);
            setIntent(intent);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        overridePendingTransition(0,0);
        if(is_add_todo == true) {
            is_add_todo = false;
            todo_adapter.addItem(new Todo_Data(todo_content));
            todo_adapter.notifyDataSetChanged();
        } else if (is_modify_todo == true) {
            is_modify_todo = false;
            todo_adapter.modifyItem(pos, new Todo_Data(todo_content));
            todo_adapter.notifyDataSetChanged();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        overridePendingTransition(0,0);
    }

    @Override
    public void onBackPressed() {
        if (System.currentTimeMillis() > backKeyPressedTime + 2000 ) { // 2초 내로 한 번 더 뒤로가기 입력 없으면 문구 출력
            backKeyPressedTime = System.currentTimeMillis();
            toast = Toast.makeText(this, "\'뒤로\' 버튼을 한번 더 누르시면 종료됩니다.", Toast.LENGTH_SHORT);
            ViewGroup group = (ViewGroup)toast.getView();
            TextView msgTextView = (TextView)group.getChildAt(0);
            msgTextView.setTextSize(TypedValue.COMPLEX_UNIT_DIP,14);
            toast.show();
            return;

        }

        if(System.currentTimeMillis() <= backKeyPressedTime +2000) { // 2초 내로 한 번 더 뒤로가기 입력 있으면 종료
            finishAffinity();
            toast.cancel();
        }
    }
}

//public class todo extends Fragment {
//    private View view;
//    private FloatingActionButton add_todo;
//    public TextView mInputDisplay;
//
//    public static final String TAG = "todoFragment";
//
//    @Nullable
//    @Override
//    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
//        view = inflater.inflate(R.layout.todo, container, false);
//
//        add_todo = view.findViewById(R.id.floating_action_button_todo);
//        add_todo.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Log.d(TAG, "onclick : opening dialog");
//                todo_new_task dialog = new todo_new_task();
//                dialog.show(getFragmentManager(), "todo_dialog");
//            }
//        });
//        return view;
//    }
//
//}

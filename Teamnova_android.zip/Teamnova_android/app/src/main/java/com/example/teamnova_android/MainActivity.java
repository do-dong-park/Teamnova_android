package com.example.teamnova_android;

import android.content.Intent;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import static com.example.teamnova_android.studyEndTime_modify_dialog.is_modify_studyTime;
import static com.example.teamnova_android.timer_exit_ConcenRate_dialog.is_add_timer;
import static com.example.teamnova_android.timer_modify_ConcenRate_dialog.is_modify_rate;


public class MainActivity extends AppCompatActivity {
    androidx.appcompat.widget.Toolbar Toolbar;
    private BottomNavigationView bottomNavigationView; // 바텀 네비게이션 뷰
    private FragmentManager fm;
    private FragmentTransaction ft;
    private todo todo;
//    private timer timer;
    private memo memo;
    private TextView ratingValue;
    private long backKeyPressedTime = 0; // 마지막으로 뒤로가기 버튼 눌렀던 시간 저장
    private Toast toast; // 첫번째 뒤로가기 버튼 누를 때 표시 문구
    private String rate, getRate, modified_rate;
    private int position;
    private Long start_time, end_time, modified_startTime, modified_endTime;
    private Intent intent;
    private FloatingActionButton add_timer;
    private double DoubleRate;
    RecyclerViewEmptySupport recyclerView;
    Timer_Record_Adapter timer_record_adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        ratingValue = (TextView)findViewById(R.id.ratingValue);
        recyclerView = (RecyclerViewEmptySupport)findViewById(R.id.main_recyclerview);
        recyclerView.setEmptyView(findViewById(R.id.list_empty));
        setRecyclerView();

        Toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(Toolbar);

        //추가된 소스코드, Toolbar의 왼쪽에 버튼을 추가하고 버튼의 아이콘을 바꾼다.
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_baseline_login_24);

        getSupportActionBar().setTitle("");  //해당 액티비티의 툴바에 있는 타이틀을 공백으로 처리

        bottomNavigationView = findViewById(R.id.bottomNavigationView);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.action_todo:
                        intent = new Intent(getApplicationContext(), todo.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                        intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                        startActivity(intent);
                        break;
                    case R.id.action_memo:
                        intent = new Intent(getApplicationContext(), memo.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                        intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                        startActivity(intent);
                        break;
                    case R.id.action_timer:
                        fm = getSupportFragmentManager();
                        ft = fm.beginTransaction();
                        break;
                }
                return true;
            }
        });

        add_timer = findViewById(R.id.floating_action_button_timer);
        add_timer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                timer_select_dialog dialog = new timer_select_dialog();
                dialog.show(getSupportFragmentManager(), "timer_dialog");
            }
        });


    }

    //레이아웃 및 어뎁터 결정.
    public void setRecyclerView() {
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getApplicationContext());
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(linearLayoutManager);

        timer_record_adapter = new Timer_Record_Adapter(this, R.layout.timer_record_list_item);
        recyclerView.setAdapter(timer_record_adapter);
    }

        //추가된 소스코드, bottomNavigationView 추가
//        bottomNavigationView = findViewById(R.id.bottomNavigationView);
//        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
//            @Override
//            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
//                switch (menuItem.getItemId()) {
//                    case R.id.action_todo:
//                        setFrag(0);
//                        break;
//                    case R.id.action_timer:
//                        setFrag(1);
//                        break;
//                    case R.id.action_memo:
//                        setFrag(2);
//                        break;
//
//
//                }
//                return true;
//            }
//        });
//        todo = new todo();
//        timer = new timer();
//        memo = new memo();
//        setFrag(1); // 첫 프래그먼트는 뭐로 지정해줄 것인지 선택

//    }

    //프래그먼트 교체가 일어남.
//    private void setFrag(int n) {
//        fm = getSupportFragmentManager();
//        ft = fm.beginTransaction();
//        switch(n) {
//            case 0:
//                ft.replace(R.id.main_frame, todo);
//                ft.commit();
//                break;
//            case 1:
//                ft.replace(R.id.main_frame, timer);
//                ft.commit();
//                break;
//            case 2:
//                ft.replace(R.id.main_frame, memo);
//                ft.commit();
//                break;
//        }
//    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        //return super.onCreateOptionsMenu(menu);
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu, menu);
        return true;

    }


    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        //return super.onOptionsItemSelected(item);
        switch (item.getItemId()) {
            case R.id.action_settings:
                // User chose the "Settings" item, show the app settings UI...
                startActivity(new Intent(this, SettingActivity.class));
                return true;

            case android.R.id.home: //로그인 버튼 클릭시,
                startActivity(new Intent(this, login.class));
                return true;
        }
        return super.onOptionsItemSelected(item);

    }

    @Override
    public void onBackPressed() {
        if (System.currentTimeMillis() > backKeyPressedTime + 2000 ) { // 2초 내로 한 번 더 뒤로가기 입력 없으면 문구 출력
            backKeyPressedTime = System.currentTimeMillis();
            toast = Toast.makeText(this, "\'뒤로\' 버튼을 한번 더 누르시면 종료됩니다.", Toast.LENGTH_SHORT);
            ViewGroup group = (ViewGroup)toast.getView();
            TextView msgTextView = (TextView)group.getChildAt(0);
            msgTextView.setTextSize(TypedValue.COMPLEX_UNIT_DIP,14);
            toast.show();
            return;

        }

        if(System.currentTimeMillis() <= backKeyPressedTime +2000) { // 2초 내로 한 번 더 뒤로가기 입력 있으면 종료
            finishAffinity();
            toast.cancel();
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if(null != intent && is_add_timer == true) {
            rate = intent.getStringExtra("rating");
            start_time = intent.getLongExtra("Start_time",0);
            end_time = intent.getLongExtra("End_time",0);
            setIntent(intent);
        } else if (null != intent && is_modify_rate == true ) {
            modified_rate = intent.getStringExtra("rating");
            position = intent.getIntExtra("position",0);
            setIntent(intent);
        } else if (null != intent && is_modify_studyTime == true ) {
            position = intent.getIntExtra("position",0);
            modified_startTime = intent.getLongExtra("startTime",0);
            modified_endTime = intent.getLongExtra("endTime",0);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        overridePendingTransition(0,0);

//        getRate = preferenceManager.getString(this, "rating");
//
//        if (rate == null) {
//            if (getRate.isEmpty() == true) {
//                // 입력값도 없고, 저장된 값도 없을 때,
//                ratingValue.setText("0.0");
//            } else {
//                //입력값은 없지만, 저장된 값은 있을 때,
//                getRate = preferenceManager.getString(this, "rating");
//                ratingValue.setText(getRate);
//            }
//        } else {
//            //입력값이 있을 때
//            ratingValue.setText(rate);
//        }

        if (is_add_timer == true) {
            is_add_timer = false;

            timer_record_adapter.addItem(new Timer_Data(start_time, end_time, rate));
            timer_record_adapter.notifyDataSetChanged();

        } else if (is_modify_rate == true) {
            is_modify_rate = false;
            long startTime =timer_record_adapter.timer_record_data.get(position).getStart_time();
            long endTime = timer_record_adapter.timer_record_data.get(position).getEnd_time();

            timer_record_adapter.modifyItem(position, new Timer_Data(startTime,endTime, modified_rate));
            timer_record_adapter.notifyDataSetChanged();
        } else if (is_modify_studyTime == true) {
            is_modify_studyTime = false;
            String rate = timer_record_adapter.timer_record_data.get(position).getRate();
            timer_record_adapter.modifyItem(position, new Timer_Data(modified_startTime,modified_endTime,rate));
        }
    }


    @Override
    protected void onPause() {
        super.onPause();
//        // textview에 있는 값 받아와서 저장하기?
//        String saveRate = ratingValue.getText().toString();
//
//        preferenceManager.setString(this, "rating", saveRate);  // rate값을 db에 저장함.
    }


}
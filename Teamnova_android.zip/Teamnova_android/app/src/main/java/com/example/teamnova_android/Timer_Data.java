package com.example.teamnova_android;

public class Timer_Data {
    long start_time;
    long end_time;
    String rate;

    public Timer_Data(long start_time, long end_time, String rate) {
        this.start_time = start_time;
        this.end_time = end_time;
        this.rate = rate;
    }

    public long getStart_time() {
        return start_time;
    }

    public void setStart_time(long start_time) {
        this.start_time = start_time;
    }

    public long getEnd_time() {
        return end_time;
    }

    public void setEnd_time(long end_time) {
        this.end_time = end_time;
    }

    public String getRate() {
        return rate;
    }

    public void setRate(String rate) {
        this.rate = rate;
    }
}

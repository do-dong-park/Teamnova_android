package com.example.teamnova_android;

import android.content.Intent;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class login extends AppCompatActivity {
    private EditText Email, Password;
    private Button Login;
    private TextView findId, findPassword, signUp;
    private Toast toast;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

        Email = (EditText)findViewById(R.id.Email);
        Password = (EditText)findViewById(R.id.Password);
        Login = (Button)findViewById(R.id.login);
        findId = (TextView)findViewById(R.id.findId);
        findPassword = (TextView)findViewById(R.id.findPassword);
        signUp = (TextView)findViewById(R.id.signUp);

        Intent intent = getIntent();

        String email = intent.getStringExtra("email");
        String password = intent.getStringExtra("password");

        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String loginEmail = Email.getText().toString();
                String loginPassword = Password.getText().toString();

                if (loginEmail.equals(email) == true && loginPassword.equals(password) == true ) {
                    toast = Toast.makeText(getApplicationContext(), "로그인 성공", Toast.LENGTH_SHORT);
                    toast.show();
                    Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);

                } else if (loginEmail.isEmpty() == true){
                    // Email 입력해주세요.
                    toast = Toast.makeText(getApplicationContext(), "이메일을 입력해주세요.", Toast.LENGTH_SHORT);
                    toast.show();
                } else if (loginPassword.isEmpty() == true){
                    // 비밀번호 입력해주세요.
                    toast = Toast.makeText(getApplicationContext(), "비밀번호를 입력해주세요.", Toast.LENGTH_SHORT);
                    toast.show();
                } else {
                    // 로그인 실패
                    Email.setText("");
                    Password.setText("");
                    toast = Toast.makeText(getApplicationContext(), "등록되지 않은 이메일이거나 \n이메일 또는 비밀번호를 잘못 입력했습니다.", Toast.LENGTH_SHORT);
                    ViewGroup group = (ViewGroup)toast.getView();
                    TextView msgTextView = (TextView)group.getChildAt(0);
                    msgTextView.setTextSize(TypedValue.COMPLEX_UNIT_DIP,14);
                    toast.show();
                }

            }
        });

        signUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), login_signUp.class));
            }
        });
    }

}

package com.example.teamnova_android;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;

import java.util.ArrayList;
import java.util.Locale;

import static com.example.teamnova_android.timer_modify_set_dialog.modify_timerSet;
import static com.example.teamnova_android.timer_set_dialog.add_timerSet;

public class timer_preset extends AppCompatActivity {
    androidx.appcompat.widget.Toolbar Toolbar;
    public static final String TAG = "TimerSet_Activity";

    private ArrayList<timer_preset_data> item = new ArrayList<>();
    private timer_preset_adapter itemAdapter;
    private RecyclerViewEmptySupport recyclerView;
    private int hour,minute,second,position;
    private String title;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.timer_grid_layout);

        Toolbar = (androidx.appcompat.widget.Toolbar) findViewById(R.id.toolbar_timer_grid);
        setSupportActionBar(Toolbar);
        getSupportActionBar().setTitle("타이머");  //해당 액티비티의 툴바에 있는 타이틀을 공백으로 처리

        recyclerView = findViewById(R.id.timer_preset_recyclerview);
        recyclerView.setEmptyView(findViewById(R.id.list_empty));

        GridLayoutManager gridLayoutManager = new GridLayoutManager(this, 2);
        recyclerView.setLayoutManager(gridLayoutManager);

        itemAdapter = new timer_preset_adapter(this, item);

        recyclerView.setAdapter(itemAdapter);

        itemAdapter.addItem(new timer_preset_data ("타이머 1", "01:00:00"));
        itemAdapter.notifyDataSetChanged();

        itemAdapter.addItem(new timer_preset_data ("타이머 2", "02:00:00"));
        itemAdapter.notifyDataSetChanged();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
//        return super.onCreateOptionsMenu(menu);
        MenuInflater menuInflater =  getMenuInflater();
        menuInflater.inflate(R.menu.timer_preset_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.add_timer:
                Log.d(TAG, "onclick : opening timerSet dialog");

                timer_set_dialog dialog = new timer_set_dialog();
                dialog.show(getSupportFragmentManager(), "timer_set_dialog");
        }
        return true;
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if(null != intent && add_timerSet == true) {
            hour = intent.getIntExtra("hour",0);
            minute = intent.getIntExtra("minute",0);
            second = intent.getIntExtra("second",0);
            title = intent.getStringExtra("title");
            setIntent(intent);
        } else if (null != intent && modify_timerSet == true) {
            position = intent.getIntExtra("position",0);
            hour = intent.getIntExtra("hour",0);
            minute = intent.getIntExtra("minute",0);
            second = intent.getIntExtra("second",0);
            title = intent.getStringExtra("title");
            setIntent(intent);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if(add_timerSet == true) {
            add_timerSet = false;
            String timeSet = String.format(Locale.getDefault(), "%02d:%02d:%02d",hour,minute,second);

            Log.d(TAG, "onclick : 아이템 추가하기");
            itemAdapter.addItem(new timer_preset_data (title, timeSet));
            itemAdapter.notifyDataSetChanged();
        } else if (modify_timerSet == true) {
            modify_timerSet = false;
            String timeSet = String.format(Locale.getDefault(), "%02d:%02d:%02d",hour,minute,second);
            Log.d(TAG, "onclick : 아이템 수정하기");
            itemAdapter.modifyItem(position, new timer_preset_data (title, timeSet));
            itemAdapter.notifyDataSetChanged();
        }
    }
}



package com.example.teamnova_android;

public class Todo_Data {
    String Todo_content;

    public String getTodo_content() {
        return Todo_content;
    }

    public void setTodo_content(String todo_content) {
        Todo_content = todo_content;
    }

    public Todo_Data(String todo_content) {
        Todo_content = todo_content;


    }
}
